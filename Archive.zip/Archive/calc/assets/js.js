 "use strict";
 let display = document.querySelector('#display');
 let button = document.querySelectorAll('.button');
 let operand = document.querySelectorAll('.operand');
 let result = document.querySelector('#result');
 let clear = document.querySelector('.clear');
 let currentString = display.innerHTML;
 console.log(currentString)
 let lastChar = currentString[currentString.length - 1];

 button.forEach(n => {   n.addEventListener("click", function(e) {     display.innerHTML += n.innerHTML;   }); });

 operand.forEach(o => {  
     o.addEventListener("click", function(e) {    
         var currentString = display.innerHTML;    
         var lastChar = currentString[currentString.length - 1];    
         if (lastChar === "+" || lastChar === "-" || lastChar === "*" || lastChar === "/") {      
             var newString = currentString.substring(0, currentString.length - 1) + e.target.innerHTML;      
             display.innerHTML = newString;    
         } else if (currentString.length == 0) {       return;     } else {       display.innerHTML += o.innerHTML;     }  
     });
 });

 result.addEventListener("click", function() {  
     let inputString = display.innerHTML;  
     let divide = inputString.indexOf("/");  
     let multiply = inputString.indexOf("*");  
     let subtract = inputString.indexOf("-");  
     let add = inputString.indexOf("+");  
     let firstDigit = '';  
     let secondDigit = '';  
     let result = 0;

       
     if (divide != -1) {    
         firstDigit = inputString.substring(0, divide);    
         secondDigit = inputString.substring(divide + 1, inputString.length - 1);    
         result = Number(firstDigit) / Number(secondDigit);  
     } else if (multiply != -1) {    
         firstDigit = inputString.substring(0, multiply);    
         secondDigit = inputString.substring(multiply + 1, inputString.length - 1);    
         result = Number(firstDigit) * Number(secondDigit);  
     } else if (subtract != -1) {    
         firstDigit = inputString.substring(0, subtract);    
         secondDigit = inputString.substring(subtract + 1, inputString.length - 1);    
         result = Number(firstDigit) - Number(secondDigit);  
     } else if (add != -1) {    
         firstDigit = inputString.substring(0, add);    
         secondDigit = inputString.substring(add + 1, inputString.length - 1);    
         result = Number(firstDigit) + Number(secondDigit);  
     }    
     display.innerHTML = result;
 });

 clear.addEventListener("click", function() {   display.innerHTML = ""; })