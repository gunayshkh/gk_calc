let button = document.querySelectorAll(".btn");
let card = document.querySelectorAll(".card");
button.forEach((e, i) => {
    e.addEventListener('click', function() {
        console.log(i)
        document.querySelector(".active-card").classList.remove("active-card");

        card[i].classList.add("active-card")
    })


});